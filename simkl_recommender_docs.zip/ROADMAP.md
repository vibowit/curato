# Roadmap

## Etap 0 -- fundament

-   [ ] Repozytorium, konfiguracja i struktura modułów.
-   [ ] FastAPI, SQLite, migracje.
-   [ ] Logowanie, obsługa błędów, konfiguracja sekretów.
-   [ ] Testy i CI.

**Akceptacja:** aplikacja uruchamia się lokalnie, migracje i testy
przechodzą.

## Etap 1 -- Simkl

-   [ ] Rejestracja aplikacji i OAuth zgodny z aktualną dokumentacją.
-   [ ] Odczyt historii, ocen i Plan to Watch.
-   [ ] Lokalna synchronizacja przyrostowa.
-   [ ] Test zapisu pojedynczej zaakceptowanej pozycji.

**Akceptacja:** rzeczywiste dane są poprawnie zapisane lokalnie; zapis
do Simkl jest kontrolowany i idempotentny.

## Etap 2 -- profil gustu

-   [ ] Analiza historii i ocen.
-   [ ] Pierwszy profil JSON z wagami i confidence.
-   [ ] Wersjonowanie i ręczna korekta profilu.

**Akceptacja:** profil ma uzasadnienie i można odtworzyć, z jakich
danych powstał.

## Etap 3 -- rekomendacje

-   [ ] Integracja TMDB.
-   [ ] Generowanie i normalizacja kandydatów.
-   [ ] Filtry obejrzanych, Plan to Watch i odrzuconych.
-   [ ] Ranking regułowy i ocena LLM.
-   [ ] Dywersyfikacja i zapis przebiegów.

**Akceptacja:** system tworzy listę 10 filmów i 5 seriali bez duplikatów
i z uzasadnieniami.

## Etap 4 -- panel i zatwierdzanie

-   [ ] Lista rekomendacji.
-   [ ] Decyzje: zaakceptuj, odrzuć, już widziałem, później.
-   [ ] Zbiorcze dodawanie zaakceptowanych do Simkl.
-   [ ] Historia przebiegów i decyzji.

**Akceptacja:** pełny przepływ od listy do Plan to Watch działa bez
automatycznego zapisu.

## Etap 5 -- MCP i harmonogram

-   [ ] MCP STDIO dla Antigravity.
-   [ ] MCP HTTPS dla ChatGPT, po weryfikacji obsługi w docelowym
    środowisku.
-   [ ] Cotygodniowy job i generowanie na żądanie.
-   [ ] Monitoring i powiadomienie o nowej edycji.

**Akceptacja:** oba interfejsy korzystają z tego samego profilu i
historii.

## Po MVP

Embeddingi, bardziej zaawansowana personalizacja, analiza zmian gustu,
powiadomienia Pushover i dodatkowe źródła metadanych.
